flaskapp
============================================================
| Create a flask project one by one is very troublesome to me.
| This project can create base files of flask project.

